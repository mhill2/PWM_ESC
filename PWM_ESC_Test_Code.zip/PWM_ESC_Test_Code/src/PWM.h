/*
 * PWM.h
 *
 *  Created on: 18 Sep 2019
 *      Author: mhill2
 */

#include <common.h>
#include <drivers/pwr/adi_pwr.h>
#include <drivers/tmr/adi_tmr.h>
#include "Timer.h"

#ifndef PWM_H_
#define PWM_H_

void Initialise_PWM(void);
void Arm_ESC(void);
void Motor_Test1(void);
void Motor_Test2(void);

#endif /* PWM_H_ */
