#include <common.h>
#include <drivers/pwr/adi_pwr.h>
#include <drivers/tmr/adi_tmr.h>
#include "Timer.h"
#include "PWM.h"

int main()
{
	Motor_Test1(); //Test the PWM
}

