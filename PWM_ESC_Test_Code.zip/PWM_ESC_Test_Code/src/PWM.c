#include <common.h>
#include <drivers/pwr/adi_pwr.h>
#include <drivers/tmr/adi_tmr.h>
#include "Timer.h"
#include "PWM.h"

#define GP2_LOAD_VALUE_FOR_20ms_PERIOD 32500 //PWM Must have a 20ms period

#define TIMER2_TIMER2_OUT_PORTP2_MUX  ((uint16_t) ((uint16_t) 2<<2))

  ADI_TMR_CONFIG        tmrConfig;
  ADI_TMR_RESULT        eResult;
  ADI_TMR_PWM_CONFIG   	pwmConfig;

void GP2CallbackFunction(void *pCBParam, uint32_t Event, void  * pArg)
{
}

void Initialise_PWM(void) // Set up the PWM settings
{
	timer_start();

	common_Init();

	adi_pwr_Init();
	adi_pwr_SetClockDivider(ADI_CLOCK_HCLK, 1u);
	adi_pwr_SetClockDivider(ADI_CLOCK_PCLK, 1u);

	*((volatile uint32_t *)REG_GPIO2_CFG) = TIMER2_TIMER2_OUT_PORTP2_MUX; // Use Timer2 Pin

	adi_tmr_Init(ADI_TMR_DEVICE_GP2, GP2CallbackFunction, NULL, true);

	tmrConfig.bCountingUp  = false;
	tmrConfig.bPeriodic    = true;
	tmrConfig.ePrescaler   = ADI_TMR_PRESCALER_16;
	tmrConfig.eClockSource = ADI_TMR_CLOCK_HFOSC;
	tmrConfig.nLoad        = GP2_LOAD_VALUE_FOR_20ms_PERIOD;
	tmrConfig.nAsyncLoad   = GP2_LOAD_VALUE_FOR_20ms_PERIOD;
	tmrConfig.bReloading   = true;
	tmrConfig.bSyncBypass  = false;

	eResult = adi_tmr_ConfigTimer(ADI_TMR_DEVICE_GP2, &tmrConfig);
	DEBUG_RESULT("Error configuring GP2 PWM.", eResult, ADI_TMR_SUCCESS);
}
void Arm_ESC(void)
{
	// To ARM the ESC, there must be a maximum PWM signal sent to the ESC before a minimum PWM is sent to the ESC, with suitable time
	pwmConfig.eOutput      = ADI_TMR_PWM_OUTPUT_0;
    pwmConfig.bMatch       = true;
	pwmConfig.bIdleHigh    = false;
	pwmConfig.nMatchValue  = (uint16_t) (GP2_LOAD_VALUE_FOR_20ms_PERIOD/10); // Send Maximum PWN width which is 2000 us
	eResult = adi_tmr_ConfigPwm(ADI_TMR_DEVICE_GP2, &pwmConfig);
	DEBUG_RESULT("Error configuring GP2 PWM.", eResult, ADI_TMR_SUCCESS);

	eResult = adi_tmr_Enable(ADI_TMR_DEVICE_GP2, true);
	timer_sleep(400);
	DEBUG_RESULT("Error configuring GP2 PWM.", eResult, ADI_TMR_SUCCESS);

	pwmConfig.nMatchValue  = (uint16_t) (GP2_LOAD_VALUE_FOR_20ms_PERIOD/28); // Send the Minimum PWM width which is 700 us
	eResult = adi_tmr_ConfigPwm(ADI_TMR_DEVICE_GP2, &pwmConfig);
	eResult = adi_tmr_Enable(ADI_TMR_DEVICE_GP2, true);

	timer_sleep(400);
}

void Motor_Test1(void) // Test the motor by using a constant speed
{
	 Initialise_PWM();
	 Arm_ESC();
	 pwmConfig.eOutput      = ADI_TMR_PWM_OUTPUT_0;
	 pwmConfig.bMatch       = true;
	 pwmConfig.bIdleHigh    = false;
	 pwmConfig.nMatchValue  = (uint16_t) (GP2_LOAD_VALUE_FOR_20ms_PERIOD/15); // PWM for the motor must be between 1000us to 2000us
	 eResult = adi_tmr_ConfigPwm(ADI_TMR_DEVICE_GP2, &pwmConfig);
	 eResult = adi_tmr_Enable(ADI_TMR_DEVICE_GP2, true);
}

void Motor_Test2(void) // Test the motor by incrementing all possible motor speed
{
	Initialise_PWM();
	Arm_ESC();
	for (int i=20; i>=10; i--)
	{
		 pwmConfig.eOutput      = ADI_TMR_PWM_OUTPUT_0;
		 pwmConfig.bMatch       = true;
	     pwmConfig.bIdleHigh    = false;
		 pwmConfig.nMatchValue  = (uint16_t) (GP2_LOAD_VALUE_FOR_20ms_PERIOD/i); // change this value for servo angle
		 eResult = adi_tmr_ConfigPwm(ADI_TMR_DEVICE_GP2, &pwmConfig);
		 eResult = adi_tmr_Enable(ADI_TMR_DEVICE_GP2, true);
		 timer_sleep(500);
	 }
}


